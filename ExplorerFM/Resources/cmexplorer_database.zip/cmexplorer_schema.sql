SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `attribute` (
  `ID` int(11) NOT NULL,
  `name` varchar(75) COLLATE utf8_bin NOT NULL,
  `type_ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `attributech` (
  `ID` int(10) UNSIGNED NOT NULL,
  `name` varchar(75) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `attribute_type` (
  `ID` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `club` (
  `ID` int(11) NOT NULL,
  `LongName` varchar(51) COLLATE utf8_bin NOT NULL,
  `ShortName` varchar(26) COLLATE utf8_bin NOT NULL,
  `StadiumOwner` tinyint(1) NOT NULL,
  `PLC` tinyint(1) NOT NULL,
  `NationID` int(11) DEFAULT NULL,
  `DivisionID` int(11) DEFAULT NULL,
  `DivisionPreviousID` int(11) DEFAULT NULL,
  `LastPosition` int(11) DEFAULT NULL,
  `DivisionReserveID` int(11) DEFAULT NULL,
  `Statut` int(11) NOT NULL,
  `Bank` int(11) DEFAULT NULL,
  `StadiumID` int(11) DEFAULT NULL,
  `StadiumReserveID` int(11) DEFAULT NULL,
  `MatchDay` int(11) DEFAULT NULL,
  `AverageAttendance` int(11) DEFAULT NULL,
  `MinimumAttendance` int(11) DEFAULT NULL,
  `MaximumAttendance` int(11) DEFAULT NULL,
  `Facilities` int(11) DEFAULT NULL,
  `Reputation` int(11) DEFAULT NULL,
  `HomeShirtForegroundID` int(11) DEFAULT NULL,
  `HomeShirtBackgroundID` int(11) DEFAULT NULL,
  `AwayShirtForegroundID` int(11) DEFAULT NULL,
  `AwayShirtBackgroundID` int(11) DEFAULT NULL,
  `ThirdShirtForegroundID` int(11) DEFAULT NULL,
  `ThirdShirtBackgroundID` int(11) DEFAULT NULL,
  `LikedStaffID1` int(11) DEFAULT NULL,
  `LikedStaffID2` int(11) DEFAULT NULL,
  `LikedStaffID3` int(11) DEFAULT NULL,
  `DislikedStaffID1` int(11) DEFAULT NULL,
  `DislikedStaffID2` int(11) DEFAULT NULL,
  `DislikedStaffID3` int(11) DEFAULT NULL,
  `RivalClubsID1` int(11) DEFAULT NULL,
  `RivalClubsID2` int(11) DEFAULT NULL,
  `RivalClubsID3` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `coach` (
  `ID` int(11) NOT NULL,
  `Firstname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Lastname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Commonname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `DateOfBirth` datetime DEFAULT NULL,
  `YearOfBirth` int(11) DEFAULT NULL,
  `JobClub` int(11) NOT NULL,
  `JobNation` int(11) NOT NULL,
  `NationID1` int(11) DEFAULT NULL,
  `NationID2` int(11) DEFAULT NULL,
  `Caps` int(11) NOT NULL,
  `IntGoals` int(11) NOT NULL,
  `ClubContractID` int(11) DEFAULT NULL,
  `DateContractStart` datetime DEFAULT NULL,
  `DateContractEnd` datetime DEFAULT NULL,
  `Value` int(11) NOT NULL,
  `Wage` int(11) NOT NULL,
  `NatClubContractID` int(11) DEFAULT NULL,
  `FavClubID1` int(11) DEFAULT NULL,
  `FavClubID2` int(11) DEFAULT NULL,
  `FavClubID3` int(11) DEFAULT NULL,
  `FavStaffID1` int(11) DEFAULT NULL,
  `FavStaffID2` int(11) DEFAULT NULL,
  `FavStaffID3` int(11) DEFAULT NULL,
  `DislikeClubID1` int(11) DEFAULT NULL,
  `DislikeClubID2` int(11) DEFAULT NULL,
  `DislikeClubID3` int(11) DEFAULT NULL,
  `DislikeStaffID1` int(11) DEFAULT NULL,
  `DislikeStaffID2` int(11) DEFAULT NULL,
  `DislikeStaffID3` int(11) DEFAULT NULL,
  `CurrentAbility` int(11) NOT NULL,
  `PotentialAbility` int(11) NOT NULL,
  `HomeReputation` int(11) NOT NULL,
  `CurrentReputation` int(11) NOT NULL,
  `WorldReputation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `coach_attributech` (
  `coach_ID` int(10) UNSIGNED NOT NULL,
  `attributech_ID` int(10) UNSIGNED NOT NULL,
  `rate` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `confederation` (
  `ID` int(11) NOT NULL,
  `Name` varchar(25) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Name3` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PeopleName` varchar(25) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `FedName` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `FedSigle` varchar(25) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Strength` decimal(3,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `country` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NameShort` varchar(25) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Name3` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ContinentID` int(11) DEFAULT NULL,
  `SelectionID` int(11) DEFAULT NULL,
  `is_EU` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `meta_field` (
  `ID` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `table_ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `meta_language` (
  `iso_3` char(3) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `iso_2` char(2) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `meta_table` (
  `ID` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `meta_translation` (
  `field_ID` int(10) UNSIGNED NOT NULL,
  `language_iso_3` char(3) COLLATE utf8_bin NOT NULL,
  `value_ID` int(10) UNSIGNED NOT NULL,
  `value` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `player` (
  `ID` int(11) NOT NULL,
  `Firstname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Lastname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Commonname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `DateOfBirth` datetime DEFAULT NULL,
  `YearOfBirth` int(11) DEFAULT NULL,
  `JobClub` int(11) NOT NULL,
  `JobNation` int(11) NOT NULL,
  `NationID1` int(11) DEFAULT NULL,
  `NationID2` int(11) DEFAULT NULL,
  `Caps` int(11) NOT NULL,
  `IntGoals` int(11) NOT NULL,
  `ClubContractID` int(11) DEFAULT NULL,
  `DateContractStart` datetime DEFAULT NULL,
  `DateContractEnd` datetime DEFAULT NULL,
  `Value` int(11) DEFAULT NULL,
  `Wage` int(11) DEFAULT NULL,
  `NatClubContractID` int(11) DEFAULT NULL,
  `FavClubID1` int(11) DEFAULT NULL,
  `FavClubID2` int(11) DEFAULT NULL,
  `FavClubID3` int(11) DEFAULT NULL,
  `FavStaffID1` int(11) DEFAULT NULL,
  `FavStaffID2` int(11) DEFAULT NULL,
  `FavStaffID3` int(11) DEFAULT NULL,
  `DislikeClubID1` int(11) DEFAULT NULL,
  `DislikeClubID2` int(11) DEFAULT NULL,
  `DislikeClubID3` int(11) DEFAULT NULL,
  `DislikeStaffID1` int(11) DEFAULT NULL,
  `DislikeStaffID2` int(11) DEFAULT NULL,
  `DislikeStaffID3` int(11) DEFAULT NULL,
  `CurrentAbility` int(11) DEFAULT NULL,
  `PotentialAbility` int(11) DEFAULT NULL,
  `HomeReputation` int(11) DEFAULT NULL,
  `CurrentReputation` int(11) DEFAULT NULL,
  `WorldReputation` int(11) DEFAULT NULL,
  `SquadNumber` int(11) DEFAULT NULL,
  `LeftFoot` int(11) DEFAULT NULL,
  `RightFoot` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `player_attribute` (
  `player_ID` int(10) UNSIGNED NOT NULL,
  `attribute_ID` int(10) UNSIGNED NOT NULL,
  `rate` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `player_position` (
  `player_ID` int(10) UNSIGNED NOT NULL,
  `position_ID` int(10) UNSIGNED NOT NULL,
  `rate` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `player_side` (
  `player_ID` int(10) UNSIGNED NOT NULL,
  `side_ID` int(10) UNSIGNED NOT NULL,
  `rate` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `position` (
  `ID` int(10) UNSIGNED NOT NULL,
  `code` varchar(2) COLLATE utf8_bin NOT NULL,
  `name` varchar(75) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `position_grid` (
  `code` varchar(5) COLLATE utf8_bin NOT NULL,
  `position_id` int(10) UNSIGNED DEFAULT NULL,
  `side_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(75) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `side` (
  `ID` int(10) UNSIGNED NOT NULL,
  `code` varchar(1) COLLATE utf8_bin NOT NULL,
  `name` varchar(75) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


ALTER TABLE `attribute`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `type_ID` (`type_ID`);

ALTER TABLE `attributech`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `attribute_type`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `name` (`name`);

ALTER TABLE `club`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `coach`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `coach_attributech`
  ADD PRIMARY KEY (`coach_ID`,`attributech_ID`);

ALTER TABLE `confederation`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `country`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `meta_field`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `table_ID` (`table_ID`),
  ADD KEY `name` (`name`);

ALTER TABLE `meta_language`
  ADD PRIMARY KEY (`iso_3`),
  ADD KEY `iso_2` (`iso_2`);

ALTER TABLE `meta_table`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `name` (`name`);

ALTER TABLE `meta_translation`
  ADD PRIMARY KEY (`field_ID`,`language_iso_3`,`value_ID`),
  ADD KEY `field_ID` (`field_ID`),
  ADD KEY `language_iso_3` (`language_iso_3`),
  ADD KEY `value_ID` (`value_ID`);

ALTER TABLE `player`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `player_attribute`
  ADD PRIMARY KEY (`player_ID`,`attribute_ID`);

ALTER TABLE `player_position`
  ADD PRIMARY KEY (`player_ID`,`position_ID`);

ALTER TABLE `player_side`
  ADD PRIMARY KEY (`player_ID`,`side_ID`);

ALTER TABLE `position`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `position_grid`
  ADD PRIMARY KEY (`code`);

ALTER TABLE `side`
  ADD PRIMARY KEY (`ID`);


ALTER TABLE `attribute`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
ALTER TABLE `attributech`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
ALTER TABLE `attribute_type`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
ALTER TABLE `meta_field`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
ALTER TABLE `meta_table`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
ALTER TABLE `position`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
ALTER TABLE `side`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `attribute`
  ADD CONSTRAINT `attribute_ibfk_1` FOREIGN KEY (`type_ID`) REFERENCES `attribute_type` (`ID`);

ALTER TABLE `meta_field`
  ADD CONSTRAINT `meta_field_ibfk_1` FOREIGN KEY (`table_ID`) REFERENCES `meta_table` (`ID`);

ALTER TABLE `meta_translation`
  ADD CONSTRAINT `meta_translation_ibfk_1` FOREIGN KEY (`field_ID`) REFERENCES `meta_field` (`ID`),
  ADD CONSTRAINT `meta_translation_ibfk_2` FOREIGN KEY (`language_iso_3`) REFERENCES `meta_language` (`iso_3`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
