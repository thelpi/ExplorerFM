
INSERT INTO `attribute_type` (`ID`, `name`) VALUES
(1, 'Goalkeeper'),
(2, 'Kickoff'),
(3, 'Physical'),
(4, 'Psychological'),
(5, 'Technical');
