
INSERT INTO `confederation` (`ID`, `Name`, `Name3`, `PeopleName`, `FedName`, `FedSigle`, `Strength`) VALUES
(0, 'Africa', 'AFR', 'African', 'Confederation of African Football', 'CAF', '0.95'),
(1, 'Asia', 'ASI', 'Asian', 'Asian Football Confederation', 'AFC', '0.90'),
(2, 'Europe', 'EUR', 'European', 'Union of European Football Associations', 'UEFA', '1.00'),
(3, 'North America', 'NAM', 'North American', 'Confederation of North and Central American and Car', 'CONCACAF', '0.90'),
(4, 'Oceania', 'OCE', 'Oceanic', 'Oceania Football Confederation', 'OFC', '0.85'),
(5, 'South America', 'SAM', 'South American', 'Confederation of South American Football', 'CONMEBOL', '1.00');
