
INSERT INTO `position` (`ID`, `code`, `name`) VALUES
(1, 'GK', 'Goal keeper'),
(2, 'SW', 'Sweeper'),
(3, 'D', 'Defender'),
(4, 'DM', 'Defensive midfielder'),
(5, 'M', 'Midfielder'),
(6, 'OM', 'Offensive midfielder'),
(7, 'S', 'Striker'),
(8, 'W', 'Wing back'),
(9, 'FR', 'Free role');
