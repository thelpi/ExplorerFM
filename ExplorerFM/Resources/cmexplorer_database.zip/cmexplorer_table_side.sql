
INSERT INTO `side` (`ID`, `code`, `name`) VALUES
(1, 'R', 'Right'),
(2, 'L', 'Left'),
(3, 'C', 'Center');
